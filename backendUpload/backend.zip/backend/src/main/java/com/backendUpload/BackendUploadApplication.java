package com.backendUpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendUploadApplication.class, args);
	}

}
